from django.contrib.auth.decorators import login_required
from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from datetime import date

from .models import Items
from .forms import ItemsForm

# Create your views here.

@login_required
def list(request):
    data = Items.objects.all()
    message = None
    message_type = None
    if 'message' in request.session and 'type' in request.session:
        message = request.session['message']
        del request.session['message']
        message_type = request.session['type']
        del request.session['type']

    return render(request, "list.html", {'data': data, 'message': message, 'message_type': message_type})


@login_required
def create(request):
    if request.method == "POST":
        try:
            form = ItemsForm(request.POST)
            if form.is_valid():
                itemObj = form.save(commit=False)
                
                if itemObj.expiry_date > date.today():
                    itemObj.save()
                    form = ItemsForm()
                    request.session['message'] = "Item added successfully! sssp"
                    request.session['type'] = "success"
                else:                    
                    message = "Unable to Add Item, Expiry date should be in future."
                    message_type = "danger"
                    return render(request, 'create.html', {'form': form, 'message': message, 'message_type': message_type})
        except Exception as ex:
            request.session['message'] = "Something went wrong"
            request.session['type'] = "danger"
    
        return redirect('list')
    
    form = ItemsForm()
    return render(request, 'create.html', {'form': form})


@login_required
def edit(request, id):
    
    itemObj = get_object_or_404(Items, pk=id)

    form = ItemsForm(request.POST or None, instance=itemObj)

    if request.POST and form.is_valid():
        
        if itemObj.expiry_date > date.today():
            form.save()

            request.session['message'] = "Item updated successfully"
            request.session['type'] = "info"
        
            return redirect('list')
        else:                    
            message = "Unable to Update Item, Expiry date should be in future."
            message_type = "danger"
            return render(request, 'create.html', {'form': form, 'message': message, 'message_type': message_type})

    return render(request, 'create.html', {'form': form})


@login_required
def delete(request, id):

    itemObj = get_object_or_404(Items, pk=id)

    Items.objects.get(pk=id).delete()
    
    request.session['message'] = "Item deleted successfully!"
    request.session['type'] = "success"
    
    return redirect('list')