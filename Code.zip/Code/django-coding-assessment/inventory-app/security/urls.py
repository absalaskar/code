from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('register-user/', views.registerUser, name='register_user'),
    path('logout/', views.logout_view, name='logout'),    
    path('', auth_views.LoginView.as_view(template_name = 'security_login.html'),  name='login'),
]